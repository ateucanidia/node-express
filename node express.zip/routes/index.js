// const userController = require('../controllers').user;
// const router = require('../userRoutes');

// module.exports = (app) => {
//     app.get('/api', (req, res) => res.status(200).send({
//         message: "welcome to the API",
//     }) 
// );
// app.post('/api/user', userController.create);
// }

