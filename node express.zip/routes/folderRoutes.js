const express = require('express');
const controller = require('./../controllers/folderController');
const router = express.Router();

router.get('/folders', controller.fetchFolder );
router.get('/folder/:id', controller.fetchFolderid);
router.post('/folders', controller.createFolder);
// router.post('/sub-folders', controller.createSubFolder);
router.put('/folder/:id', controller.updateFolder);
router.delete('/folder', controller.deleteFolder);

module.exports = router;